#!/bin/bash

printf "%d \n " $1
