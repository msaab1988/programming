#!/bin/bash

echo " Enter your directory: "
read x
du -sh "$x"
