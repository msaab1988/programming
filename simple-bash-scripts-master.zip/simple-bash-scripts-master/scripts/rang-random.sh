#!/bin/bash

shuf -i $1-$2 -n 1
